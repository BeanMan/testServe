//
//  ViewController.m
//  testServer
//
//  Created by bean on 2016/11/18.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPSessionManager.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray * titlearr = @[@"登录",@"获取信息"];
    
    for (int i = 0; i<titlearr.count; i++)
    {
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(100, 100*i, 80, 80);
        [btn setTitle:titlearr[i] forState:UIControlStateNormal];
        btn.backgroundColor = [UIColor redColor];
        btn.tag = i+1;
        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
    }
    
    
}


- (void)click:(UIButton*)btn {
    
    switch (btn.tag) {
        case 1:
        {
            [self login];
        }
        break;
        case 2:
        {
            [self requestAssetList];
        }
        break;
        
        default:
        break;
    }
    
    
}


-(void)login
{
    
    AFHTTPSessionManager *  manager=[AFHTTPSessionManager manager];
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"text/html",@"application/json",@"text/json",nil];
    NSString *url=@"http://localhost:8080/assetApp/login";
    //请求所带参数
    NSDictionary *dic = @{@"username":@"zhangsan",
                          @"password":@"123456"
                          };
    
    [manager GET:url parameters:dic progress:^(NSProgress * _Nonnull downloadProgress)
     {
         
     } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject)
     {
         NSLog(@"成功拿到的数据:%@",responseObject);

     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         NSLog(@"登录失败::%@",error);
     }];

    
}

-(void)requestAssetList
{
    
    NSString *url=@"http://localhost:8080/assetApp/assetList";
    
    AFHTTPSessionManager *  manager=[AFHTTPSessionManager manager];
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    
    //带有headers参数
    [manager.requestSerializer setValue:@"e566288ba77de98d" forHTTPHeaderField:@"sessionid"];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"text/html",@"application/json",@"text/json",nil];

    [manager POST:url parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"成功的Array:%@",responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error)
    {
        NSLog(@"获取信息失败::%@",error);
    }];
}

@end
