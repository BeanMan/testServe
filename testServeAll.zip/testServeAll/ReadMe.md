1.建立服务器链接
cd /Users/bean/Desktop/testServeAll 

2.java -jar moco-runner-0.10.2-standalone.jar start -p 8080 -g settings.json

3.终端显示运行成功然后执行XCode工程即可
